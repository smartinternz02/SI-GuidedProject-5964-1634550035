import numpy as np
import os
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image
from flask import Flask , request, render_template

app = Flask(__name__)

model = load_model(r"C:\Users\user\pneumonia3.h5")
                 
@app.route('/')
def index():
    return render_template(r'index.html')

@app.route('/predict',methods = ['GET','POST'])
def upload():
    if request.method == 'POST':
        f = request.files['image']
        print("current path")
        basepath = os.path.dirname(__file__)
        print("current path", basepath)
        filepath = os.path.join(basepath,'uploads',f.filename)
        print("upload folder is ", filepath)
        f.save(filepath)
        img = image.load_img(filepath,target_size=(128,128)) 
        x = image.img_to_array(img)
        print(x)
        a=np.expand_dims(x,axis=0)
        print(a)
        predict_x=model.predict(a) 
        classes_x=np.argmax(predict_x,axis=1)
        print("prediction",classes_x)
        index = ['Your pneumonia x-ray report is normal','You are infected! please consult the doctor.']
        text = str(index[classes_x[0]])
    return text
if __name__ == '__main__':
    app.run()
